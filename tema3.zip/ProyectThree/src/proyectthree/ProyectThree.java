
package proyectthree;

public class ProyectThree {

    public static void main(String[] args) {
       String[] nombres= {"Juan","Pedro","Diego", "Victoria", "Ana"};
       for(String imprimir : nombres){
           System.out.print(imprimir + " ");
       }
    }
  
    }
    

